//
//  CustomAnnotation.swift
//  CAguirreTopTenJuneau
//
//  Created by Cristian Aguirre on 10/15/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit
import MapKit
import Foundation

class CustomAnnotation: NSObject, MKAnnotation{
    
    //initialation of variables here:
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    
    
    //setup initialization method
    init(coordinate: CLLocationCoordinate2D, title: String, subtitle: String) {
        
        //again, selfs are for the set up initialation method
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
        
        
    }
}
