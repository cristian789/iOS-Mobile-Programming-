//
//  MainViewController.swift
//  CAguirreTopTenJuneau
//
//  Created by Cristian Aguirre on 10/14/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

   // var AtrObj = [Alaska]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

      //  readPropertyListAtr()
        
        // Do any additional setup after loading the view.
    }

    
//    func readPropertyListAtr() {
//
//        let path = Bundle.main.path(forResource: "topAttractions", ofType: "plist")!
//
//        let atrArray:NSArray = NSArray(contentsOfFile: path)!
//        print("\(atrArray)")
//
//
//        for item in atrArray {
//            //item is of type of any object and cannot be used
//            //as a subscrip dictionary with value key-pair
//            //therefore, i need ro convert item into a dictionarry
//
//            let dictionary: [String: Any] = (item as? Dictionary)!
//
//            //next, use dictionary to extract each attribute
//            //in  the dictionary before apending them in the
//            //menuObject
//
//            let atr_name = dictionary["Name"]
//            let atr_description = dictionary["Description"]
//            let atr_location = dictionary ["Location"]
//            let atr_website = dictionary["Website"]
//            let atr_phone = dictionary["Phone"]
//            let atr_hours = dictionary["Hours"]
//            let atr_fees = dictionary["Fees"]
//            let atr_picture = dictionary["Picture"]
//
//            AtrObj.append(Alaska(name: atr_name as! String, description: atr_description as! String,
//                                 location: atr_location as! String, website: atr_website as! String,
//                                 phone: atr_phone as! String, hours: atr_hours as! String,
//                                 fees: atr_fees as! String, picture: atr_picture as! String))
//
//        }//ends loop
//
//    }
//
//
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//
//        if (segue.identifier == "ATTRACTIONS"){
//
//
//
//
//
//        //first identify the detail the detail view and your choice of row
////        if (segue.identifier == "CHOICE"){
////            let destVC = segue.destination as! choiceTableViewController
////
////            if let indexPath = self.tableView.indexPathForSelectedRow{
////                //{
////                //              if ((indexPath.row)==1)
////                //                {
////                let atr:Alaska = ATRObj[indexPath.row]
////                destVC.navigationItem.title = atr.name
////                destVC.tvAtrName = atr.name
////                destVC.tvDescription = atr.description1
////                destVC.tvLocation = atr.location
////                destVC.tvWebsite = atr.website
////                destVC.tvPhone = atr.phone
////                destVC.tvHours = atr.hours
////                destVC.tvFees = atr.fees
////                destVC.tvPicture = atr.picture
////
////                // }
//           }
//
//
}
//
