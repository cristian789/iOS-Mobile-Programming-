//
//  choiceTableViewCell.swift
//  CAguirreTopTenJuneau
//
//  Created by Cristian Aguirre on 10/12/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit

class choiceTableViewCell: UITableViewCell {
    @IBOutlet weak var cellImage: UIImageView!
    @IBOutlet weak var nameCell: UILabel!
    @IBOutlet weak var priceCell: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
