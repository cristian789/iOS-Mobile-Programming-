//
//  WebsiteViewController.swift
//  CAguirreTopTenJuneau
//
//  Created by Cristian Aguirre on 10/15/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit
import WebKit

class WebsiteViewController: UIViewController {

    //,WKUIDelegate, WKNavigationDelegate
    var tvweb: String!
    
    @IBOutlet weak var web: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(tvweb)
        
        let url = URL(string: tvweb)
        let urlRequest = URLRequest(url: url!)
        web.load(urlRequest)
    }
    
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//
//
//
//    }
    
    
//    override func loadView() {
//        let webConfiguration = WKWebViewConfiguration()
//        web = WKWebView(frame: .zero, configuration: webConfiguration)
//        web.navigationDelegate = self
//        view = web
//    }
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        let myURL = URL(string:"http://www.amazon.com/")!
//        let myRequest = URLRequest(url: myURL)
//        web.load(myRequest)
//    }
//
//    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping
//        (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
//        if let serverTrust = challenge.protectionSpace.serverTrust {
//            completionHandler(.useCredential, URLCredential(trust: serverTrust))
//        }
//    }
}
