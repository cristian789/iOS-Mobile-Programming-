//
//  Alaska.swift
//  CAguirreTopTenJuneau
//
//  Created by Cristian Aguirre on 10/12/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit
import Foundation

class Alaska: NSObject {
    
    //creating custom classes that maps all the keys
    var name: String!
    var description1: String!
    var location: String!
    var website: String!
    var phone: String!
    var hours: String!
    var fees: String!
    var picture: String!
    
    //set up initialization method
    init(name: String, description: String, location: String, website: String,
         phone: String, hours: String, fees: String, picture: String){
        
                self.name = name
                self.description1 = description
                self.location = location
                self.website = website
                self.phone = phone
                self.hours = hours
                self.fees = fees
                self.picture = picture
    }

}

//this class is for the menu
class Alaska1: NSObject {
    //creating custom classes that maps all the keys
    var name1: String!
    var picture1: String!

    //set up initiziasion
    init(name1: String, picture1:String){

        self.name1 = name1
        self.picture1 = picture1
    }
}


