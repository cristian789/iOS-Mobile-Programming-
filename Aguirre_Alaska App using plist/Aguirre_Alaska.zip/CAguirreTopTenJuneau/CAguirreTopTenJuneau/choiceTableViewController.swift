//
//  choiceTableViewController.swift
//  CAguirreTopTenJuneau
//
//  Created by Cristian Aguirre on 10/12/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit

class choiceTableViewController: UITableViewController {
    //initializes array of objects to hold the plist objects

    var AtrObj = [Alaska]()


    override func viewDidLoad() {
        super.viewDidLoad()

        // Set fixed height for tableview cell.
        self.tableView.rowHeight = 100
        
        readPropertyList()
        
        addRightNavigationBarInfoButton()
    }
    
    
    func addRightNavigationBarInfoButton(){
        
        //create an Info Light button
        let button = UIButton(type: .infoDark)
        button.addTarget(self, action: #selector(self.showAboutAppView), for: .touchUpInside)
        
        
        //place the button at the top right corner of the Navigation bar
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: button)
        
    }
    //function object to show about app witb code instead of being connnected from the main
    @objc func showAboutAppView() {
        let storyboard = UIStoryboard(name: "Main", bundle:nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AboutAppNavigationController") as! UINavigationController
        self.present(controller, animated: true, completion:nil)
    }
    
    
    

    
    func readPropertyList() {
        
        let path = Bundle.main.path(forResource: "topAttraction", ofType: "plist")!
        
        let atrArray:NSArray = NSArray(contentsOfFile: path)!
        print("\(atrArray)")
        
        
        for item in atrArray {
            //item is of type of any object and cannot be used
            //as a subscrip dictionary with value key-pair
            //therefore, i need ro convert item into a dictionarry
            
            let dictionary: [String: Any] = (item as? Dictionary)!
            
            //next, use dictionary to extract each attribute
            //in  the dictionary before apending them in the
            //menuObject
            
            let atr_name = dictionary["Name"]
            let atr_description = dictionary["Description"]
            let atr_location = dictionary ["Location"]
            let atr_website = dictionary["Website"]
            let atr_phone = dictionary["Phone"]
            let atr_hours = dictionary["Hours"]
            let atr_fees = dictionary["Fees"]
            let atr_picture = dictionary["Picture"]
            
            AtrObj.append(Alaska(name: atr_name as! String, description: atr_description as! String,
                                 location: atr_location as! String, website: atr_website as! String,
                                 phone: atr_phone as! String, hours: atr_hours as! String,
                                 fees: atr_fees as! String, picture: atr_picture as! String))
            
        }//ends loop
        
        
        
    }
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return AtrObj.count
    }
    
    //uncomented
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let choice:Alaska = AtrObj[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! choiceTableViewCell
        
        // Configure the cell...
        cell.cellImage.image = UIImage(named: choice.picture)
        cell.nameCell.text = choice.name
        cell.priceCell.text = choice.fees
        
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "DETAILVIEW"){
            let destVC = segue.destination as! ViewController
            
            //prepare to send details to the detailviewcontroller
            
            if let indexPath = self.tableView.indexPathForSelectedRow {
                
                let jun:Alaska = AtrObj[indexPath.row]
                destVC.navigationItem.title = jun.name
                destVC.tvName = jun.name
                destVC.tvDescription = jun.description1
                destVC.tvLocation = jun.location
                destVC.tvWeb = jun.website
                destVC.tvPhone = jun.phone
                destVC.tvHours = jun.hours
                destVC.tvFees = jun.fees
                destVC.tvImage = jun.picture
                
                                                                    }
            
           
                    
                                                }
        if (segue.identifier == "WEBSITE"){
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let destVC = segue.destination as! WebsiteViewController
                
                let jun:Alaska = AtrObj[indexPath.row]
                destVC.tvweb = jun.website
            }
        }
        
        
    }


}
