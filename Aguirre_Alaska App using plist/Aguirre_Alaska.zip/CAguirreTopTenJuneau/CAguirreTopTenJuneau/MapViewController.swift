//
//  MapViewController.swift
//  CAguirreTopTenJuneau
//
//  Created by Cristian Aguirre on 10/15/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate {

    override func viewDidLoad() {
        
        let myLocCoordinate = CLLocationCoordinate2D( latitude: 34.010748,
                                                      longitude: -118.495575)
        //annotation is for the pin  to say the title of the place where the pin is located at
        let annotationPin = CustomAnnotation(coordinate: myLocCoordinate, title: "Santa Monica Beach ",
                                             subtitle: "One of the best attractions near Los Angeles")
        
        let mapRegion = MKCoordinateRegionMakeWithDistance(myLocCoordinate, 500,500)
        //this indicate how close you want to zoom using distance.
        
        
        mapView.setRegion(mapRegion, animated: true)
        
        mapView.addAnnotation(annotationPin)
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    

}
