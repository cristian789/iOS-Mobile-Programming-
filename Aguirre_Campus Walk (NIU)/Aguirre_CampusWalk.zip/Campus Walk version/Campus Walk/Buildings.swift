//
//  Buildings.swift
//  Campus Walk
//
//  Created by Cristian Aguirre on 11/22/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit

class Buildings: NSObject {
    
    
    //creating custom classes that maps all they keys
    
    var number:String!
    var name:String!
    var code:String!
    var lat:String!
    var long:String!
    var image:String!
    var facts:String!
   
    
    
    //set up initialization method
    init(addnumber: String, addname: String, addcode: String, addlat: String, addlong: String, addimage: String, addfacts: String)
    {
        
        self.number = addnumber
        self.name = addname
        self.code = addcode
        self.lat = addlat
        self.long = addlong
        self.image = addimage
        self.facts = addfacts
    }
}
