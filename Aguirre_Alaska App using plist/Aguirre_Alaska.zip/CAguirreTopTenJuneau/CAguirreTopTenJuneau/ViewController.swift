//
//  ViewController.swift
//  CAguirreTopTenJuneau
//
//  Created by Cristian Aguirre on 10/10/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {

    @IBOutlet weak var detImage: UIImageView!
    @IBOutlet weak var detName: UILabel!
    @IBOutlet weak var detDescription: UILabel!
   // @IBOutlet weak var detLocation: UILabel!
    //@IBOutlet weak var detWeb: UILabel!
    //@IBOutlet weak var detPhone: UILabel!
    @IBOutlet weak var detHours: UILabel!
    @IBOutlet weak var detFees: UILabel!
    
   
    
    
    
    //variables to hold data passed from the tableView
    var tvImage: String!
    var tvName: String!
    var tvDescription: String!
    var tvLocation: String!
    var tvWeb: String!
    var tvPhone: String!
    var tvHours: String!
    var tvFees: String!
    
    var phoneNum:String!
    var websiteButton:String!
    
    
    @IBAction func phoneButton(_ sender: Any) {
        //get phone# from button title
        guard let phoneNum = tvPhone      //xcode 10(sender as AnyObject).titleLabel?.text
            else {return}
        
        //create as url string w/ require protocol
        
        //  "tel ://"
        
        let myURL:NSURL = URL(string: "tel://\(phoneNum)")! as NSURL
        
        //make a call
        
        UIApplication.shared .open(myURL as URL, options: [:], completionHandler: nil)
        //UIApplication.shared open(myURL as URL, option:[:], CompletitionHandler: nil)
    }
    
    //sends the url to open with safari
//    @IBAction func websiteButton(_ sender: Any) {
//        
//        guard let websiteButton = tvWeb     //xcode 10(sender as AnyObject).titleLabel?.text
//            else {return}
//        
//        guard let requestUrl = URL(string: "\(websiteButton)")
//            else {return}
//        
//        UIApplication.shared.open(requestUrl, options: [:], completionHandler: nil)
//        
//    }
    
    @IBAction func Location(_ sender: Any) {
        let geocoder = CLGeocoder()
        
        let locationString = tvLocation
        
        geocoder.geocodeAddressString(locationString!) { (placemarks, error) in
            if let error = error {
                print(error.localizedDescription)
            } else {
                if let location = placemarks?.first?.location {
                    let query = "?ll=\(location.coordinate.latitude),\(location.coordinate.longitude)"
                    let urlString = "http://maps.apple.com/".appending(query)
                    if let url = URL(string: urlString) {
                        UIApplication.shared.open(url, options: [:], completionHandler: nil)
                    }
                }
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        detImage.image = UIImage(named: tvImage)
        detName.text = tvName
        detDescription.text = tvDescription
     //   detLocation.text = tvLocation
        //detWeb.text = tvWeb
       // detPhone.text = tvPhone
        detHours.text = tvHours
        detFees.text = tvFees
        
        
        //phoneButton(tvPhone)
        //phoneNum = tvPhone
        
        //web = tvWeb
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    override func viewDidLayoutSubviews() {
       detDescription.sizeToFit()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if (segue.identifier == "WEBSITE"){
        
                let destVC = segue.destination as! WebsiteViewController
        
                destVC.tvweb = tvWeb
    }
    
}
}



//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//    // Get the new view controller using segue.destinationViewController.
//    // Pass the selected object to the new view controller.
//    if (segue.identifier == "WEBSITE"){
//
//        let destVC = segue.destination as! WebsiteViewController
//
//        destVC.tvweb = tvWeb
//
//       // destVC.web =
//
////        if let indexPath = self.tableView.indexPathForSelectedRow {
////        }
//
//    }







