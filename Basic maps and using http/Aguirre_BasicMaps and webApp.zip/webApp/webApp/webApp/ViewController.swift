//
//  ViewController.swift
//  webApp
//
//  Created by Cristian Aguirre on 10/15/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    @IBOutlet weak var web: WKWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://www.google.com/")
        let request = URLRequest(url: url!)
        web.load(request)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

