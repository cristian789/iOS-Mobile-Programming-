//
//  AboutAppViewController.swift
//  CAguirreTopTenJuneau
//
//  Created by Cristian Aguirre on 10/14/18.
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//
//  credit sources come from https://www.tripadvisor.com, https://www.yelp.com and https://www.google.com/maps
//



import UIKit
import MessageUI

class AboutAppViewController: UIViewController,MFMailComposeViewControllerDelegate {

    @IBAction func sendFeedback(_ sender: Any) {
        
        if !MFMailComposeViewController.canSendMail() {
            print("Mail services are not available")
            return
        }
        else
        {
            
            let mailComposeVC = MFMailComposeViewController()
            
            mailComposeVC.mailComposeDelegate = self
            
            let toRecipients = ["niucsci@gmail.com"]
            
            let emailTitle = "Juneau, Alaska App Feedback"
            
            let messageBody = "Feedback for Juneau, Alaska version 1.0, Fall 2018"
            mailComposeVC.setToRecipients(toRecipients)
            mailComposeVC.setSubject(emailTitle)
            mailComposeVC.setMessageBody(messageBody, isHTML: false)
            self.present(mailComposeVC, animated: true, completion: nil)
            
            //self.dismiss(animated: true, completion: nil)
    }
}
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    //dismissing with done button back to main view
    @IBAction func doneButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "About App"
        // Do any additional setup after loading the view.
    }

//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
