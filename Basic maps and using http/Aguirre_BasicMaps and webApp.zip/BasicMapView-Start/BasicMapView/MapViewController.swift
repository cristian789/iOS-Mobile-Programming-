//
//  MapViewController.swift
//  BasicMapView
//
//  Created by Cristian Aguirre on 10/18/18
//  Copyright © 2018 Cristian Aguirre. All rights reserved.
//

import UIKit
import MapKit     //we need this for the map functions

class MapViewController: UIViewController, MKMapViewDelegate {
    @IBOutlet weak var mapView: MKMapView!    //map view oulet
    @IBOutlet weak var mapTypeSegment: UISegmentedControl!     //both of these are outlets and acions for segment control
    
    @IBAction func mapTypeControl(_ sender: UISegmentedControl) {
        let segIndex = sender.selectedSegmentIndex
        switch segIndex {   //switch statements for when pressed on either or the map view choices
        case 0:
            mapView.mapType = .standard
        case 1:
            mapView.mapType = .satellite
        case 2:
            mapView.mapType = .hybrid
        default:
            break
        }
        
        
    }
    

    override func viewDidLoad() {
        
        //annotation is for the pin  to say the title of the place where the pin is located at
        let myLocCoordinate = CLLocationCoordinate2D(latitude: 34.019455, longitude: -118.491188)
        let annotationPin  = CustomAnnotation(Coordinate: myLocCoordinate, Title: "Santa Monica", Subtitle: "Best ocean view in all L.A!")
        
        let mapRegion = MKCoordinateRegionMakeWithDistance(myLocCoordinate, 500, 500)
        //this indicate how close you want to zoom using distance.
        
        mapView.setRegion(mapRegion, animated: true)
        
        mapView.addAnnotation(annotationPin)
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
